package com.DesafioJava.DesafioJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
